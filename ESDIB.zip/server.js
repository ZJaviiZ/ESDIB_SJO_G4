import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import { MongoClient, ObjectId } from 'mongodb';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

// Cargar variables de entorno desde .env
dotenv.config();

//Configuraciones de entorno
const { MONGODB_URI, MONGODB_DB, port = process.env.PORT || 4000, API_KEY, JWT_SECRET } = process.env;

// Verificar si falta algo crítico
if (!MONGODB_URI || !MONGODB_DB || !API_KEY || !JWT_SECRET) {
    console.error('Faltan variables de entorno: MONGODB_URI, MONGODB_DB, API_KEY...');
    process.exit(1);
}

const app = express();

// Middlewares de seguridad y utilidades
app.use(helmet({
    contentSecurityPolicy: {
        useDefaults: true,
        directives: {
            "default-src": ["'self'"],
            "connect-src": ["'self'"], // llamadas fetch/XHR al mismo origen
        }
    }
}));
app.use(cors({ origin: true, credentials: true })); // Habilitar CORS
app.use(express.json()); // Parsear JSON
app.use(morgan('dev')); // Logs HTTP

// Para que se vea desde azure y no de problemas de autenticidad
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/pagina', express.static(path.join(__dirname, 'Pagina')));

// Auth por API Key
const apiKeyGuard = (req, res, next) => {
    if (req.header('x-api-key') !== process.env.API_KEY) return res.status(401).json({ error: 'No autorizado' });
    next();
};
app.use('/api', apiKeyGuard);

// Middleware de autenticación JWT
const verifyToken = (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'Acceso denegado' });

    try {
        const verified = jwt.verify(token, JWT_SECRET);
        req.user = verified;
        next();
    } catch (error) {
        res.status(400).json({ error: 'Token inválido' });
    }
};

// Conexión a MONGODB
let client;
let db;
async function connectToMongo() {
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    db = client.db(MONGODB_DB);
    console.log('✅ Conectado a MongoDB');
}


//Helpers de validación
function parseIntegerField(value, fieldName) {
    if (value === undefined || value === null || value === '') return null;
    const num = Number.parseInt(value, 10);
    if (Number.isNaN(num)) {
        throw new Error(`El campo "${fieldName}" debe ser un número entero`);
    }
    return num;
}
function parseDateField(value, fieldName) {
    if (!value) return null;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) {
        throw new Error(`El campo "${fieldName}" no es una fecha válida`);
    }
    return d;
}

//Normalizar todos los datos que se suben antes de guardarlos.
function normalizeActivityPayload(body) {
    const { nombre, descripcion, fecha, hora, lugar, inscritos_max, categoria } = body;
    if (!nombre) throw new Error('El campo "nombre" es obligatorio');

    const payload = {
        nombre: String(nombre).trim(),
        descripcion: descripcion ? String(descripcion).trim() : null,
        fecha: parseDateField(fecha, 'fecha'),
        hora: hora ? String(hora).trim() : null,
        lugar: lugar ? String(lugar).trim() : null,
        inscritos_max: parseIntegerField(inscritos_max, 'inscritos_max'),
        categoria: categoria ? String(categoria).trim() : 'Otros', // Default category
    };
    return payload;
}


//Rutas
//GET: Para listar toda la BBDD
app.get('/api/activities', async (req, res) => {
    try {
        const activities = await db.collection('activities')
            .find({})
            .sort({ _id: -1 })
            .toArray();
        res.json(activities);
    } catch (err) {
        console.error('Error en GET /api/activities:', err);
        res.status(500).json({ error: 'Error al obtener actividades' });
    }
});

//POST Crear registros
app.post('/api/activities', async (req, res) => {
    try {
        const activity = normalizeActivityPayload(req.body);

        const result = await db.collection('activities').insertOne(activity);
        const _id = result.insertedId;

        const doc = await db.collection('activities').findOne({ _id });
        res.status(201).json(doc);
    } catch (err) {
        console.error('POST /api/activities error:', err);
        res.status(400).json({ error: err.message || 'Error al crear actividad' });
    }
});

// DELETE Eliminar registros de la BBDD
app.delete('/api/activities/:id', async (req, res) => {
    try {
        const { id } = req.params;
        if (!ObjectId.isValid(id)) return res.status(400).json({ error: 'ID no válido' });

        const result = await db.collection('activities').deleteOne({ _id: new ObjectId(id) });
        if (result.deletedCount === 0) {
            return res.status(404).json({ error: 'Actividad no encontrada' });
        }
        res.json({ ok: true });
    } catch (err) {
        console.error('Error en DELETE /api/activities/:id:', err);
        res.status(500).json({ error: 'Error al eliminar actividad' });
    }
});

//Función para buscar por objectid
function buildIdFilter(id) {
    const s = String(id || '').trim();
    const or = [{ _id: s }];
    if (ObjectId.isValid(s)) or.unshift({ _id: new ObjectId(s) });
    return { $or: or };
}
//PUT Actualizar registro
app.put('/api/activities/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const filter = buildIdFilter(id);
        const payload = normalizeActivityPayload(req.body);

        // DEBUG LOGS
        console.log('[PUT] id:', id);
        console.log('[PUT] filter:', JSON.stringify(filter));

        // 1) Actualiza
        const r = await db.collection('activities').updateOne(filter, { $set: payload });

        console.log('[PUT] matched:', r.matchedCount, 'modified:', r.modifiedCount);

        // 2) Si no existía, 404
        if (r.matchedCount === 0) {
            return res.status(404).json({ error: 'Actividad no encontrada' });
        }

        // 3) Devuelve el documento actual (aunque no haya cambiado nada)
        const updated = await db.collection('activities').findOne(filter);
        console.log('[PUT] returning _id:', updated?._id);
        return res.json(updated);
    } catch (err) {
        console.error('Error en PUT /api/activities/:id', err);
        return res.status(400).json({ error: err.message || 'Error al actualizar actividad' });
    }
});

// --- AUTH ROUTES ---

// Registro
app.post('/api/auth/register', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) return res.status(400).json({ error: 'Usuario y contraseña requeridos' });

        const existingUser = await db.collection('users').findOne({ username });
        if (existingUser) return res.status(400).json({ error: 'El usuario ya existe' });

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser = {
            username,
            password: hashedPassword,
            joinedActivities: []
        };

        const result = await db.collection('users').insertOne(newUser);
        res.status(201).json({ _id: result.insertedId, username });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al registrar usuario' });
    }
});

// Login
app.post('/api/auth/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await db.collection('users').findOne({ username });
        if (!user) return res.status(400).json({ error: 'Usuario no encontrado' });

        const validPass = await bcrypt.compare(password, user.password);
        if (!validPass) return res.status(400).json({ error: 'Contraseña incorrecta' });

        const token = jwt.sign({ _id: user._id, username: user.username }, JWT_SECRET, { expiresIn: '1d' });
        res.header('auth-token', token).json({ token, username: user.username, _id: user._id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al iniciar sesión' });
    }
});

// Obtener usuario actual (incluyendo actividades)
app.get('/api/users/me', verifyToken, async (req, res) => {
    try {
        const user = await db.collection('users').findOne({ _id: new ObjectId(req.user._id) }, { projection: { password: 0 } });
        res.json(user);
    } catch (err) {
        res.status(500).json({ error: 'Error al obtener usuario' });
    }
});

// Unirse a actividad
app.post('/api/activities/:id/join', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        if (!ObjectId.isValid(id)) return res.status(400).json({ error: 'ID no válido' });

        const result = await db.collection('users').updateOne(
            { _id: new ObjectId(req.user._id) },
            { $addToSet: { joinedActivities: id } } // Evita duplicados
        );

        res.json({ ok: true, message: 'Inscrito correctamente' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al unirse a la actividad' });
    }
});

// Desapuntarse de actividad
app.delete('/api/activities/:id/join', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        if (!ObjectId.isValid(id)) return res.status(400).json({ error: 'ID no válido' });

        const result = await db.collection('users').updateOne(
            { _id: new ObjectId(req.user._id) },
            { $pull: { joinedActivities: id } }
        );

        res.json({ ok: true, message: 'Desinscrito correctamente' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al desapuntarse' });
    }
});

// --- FORUM ROUTES ---

// GET: Listar posts
app.get('/api/posts', async (req, res) => {
    try {
        const posts = await db.collection('posts')
            .find({})
            .sort({ createdAt: -1 })
            .toArray();
        res.json(posts);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al obtener posts' });
    }
});

// POST: Crear nuevo post
app.post('/api/posts', verifyToken, async (req, res) => {
    try {
        const { content } = req.body;
        if (!content) return res.status(400).json({ error: 'El contenido es obligatorio' });

        const newPost = {
            content,
            author: {
                _id: new ObjectId(req.user._id),
                username: req.user.username
            },
            createdAt: new Date(),
            replies: []
        };

        const result = await db.collection('posts').insertOne(newPost);
        res.status(201).json({ ...newPost, _id: result.insertedId });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al crear post' });
    }
});

// POST: Responder a un post
app.post('/api/posts/:id/replies', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { content } = req.body;

        if (!ObjectId.isValid(id)) return res.status(400).json({ error: 'ID no válido' });
        if (!content) return res.status(400).json({ error: 'El contenido es obligatorio' });

        const reply = {
            _id: new ObjectId(),
            content,
            author: {
                _id: new ObjectId(req.user._id),
                username: req.user.username
            },
            createdAt: new Date()
        };

        const result = await db.collection('posts').updateOne(
            { _id: new ObjectId(id) },
            { $push: { replies: reply } }
        );

        if (result.matchedCount === 0) return res.status(404).json({ error: 'Post no encontrado' });

        res.status(201).json(reply);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al responder' });
    }
});

// DELETE: Eliminar un post completo (solo el autor)
app.delete('/api/posts/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) return res.status(400).json({ error: 'ID no válido' });

        // Verificar que el usuario es el autor
        const post = await db.collection('posts').findOne({ _id: new ObjectId(id) });
        if (!post) return res.status(404).json({ error: 'Post no encontrado' });

        if (post.author._id.toString() !== req.user._id) {
            return res.status(403).json({ error: 'No tienes permiso para eliminar este post' });
        }

        await db.collection('posts').deleteOne({ _id: new ObjectId(id) });
        res.json({ ok: true, message: 'Post eliminado' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al eliminar post' });
    }
});

// DELETE: Eliminar una respuesta específica (solo el autor)
app.delete('/api/posts/:id/replies/:replyId', verifyToken, async (req, res) => {
    try {
        const { id, replyId } = req.params;

        if (!ObjectId.isValid(id) || !ObjectId.isValid(replyId)) {
            return res.status(400).json({ error: 'ID no válido' });
        }

        // Buscar el post y verificar que la respuesta existe y pertenece al usuario
        const post = await db.collection('posts').findOne({ _id: new ObjectId(id) });
        if (!post) return res.status(404).json({ error: 'Post no encontrado' });

        const reply = post.replies.find(r => r._id.toString() === replyId);
        if (!reply) return res.status(404).json({ error: 'Respuesta no encontrada' });

        if (reply.author._id.toString() !== req.user._id) {
            return res.status(403).json({ error: 'No tienes permiso para eliminar esta respuesta' });
        }

        // Eliminar la respuesta del array
        await db.collection('posts').updateOne(
            { _id: new ObjectId(id) },
            { $pull: { replies: { _id: new ObjectId(replyId) } } }
        );

        res.json({ ok: true, message: 'Respuesta eliminada' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al eliminar respuesta' });
    }
});

//Comprobador para saber si el servidor responde
app.get('/health', (req, res) => res.json({ ok: true }));

// Arranque
connectToMongo()
    .then(() => {
        app.listen(port, () => console.log(`🚀 API escuchando en http://localhost:${port}`));
    })
    .catch((err) => {
        console.error('No se pudo conectar a MongoDB:', err);
        process.exit(1);
    });

// Cierre elegante
process.on('SIGINT', async () => {
    try {
        await client?.close();
    } finally {
        process.exit(0);
    }
});
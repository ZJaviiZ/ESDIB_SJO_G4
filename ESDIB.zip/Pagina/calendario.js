const monthNames = [
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
];

let currentDate = new Date();
let currentMonth = currentDate.getMonth();
let currentYear = currentDate.getFullYear();
let allActivities = [];

const API_BASE = '/api';
const API_KEY = '23add26e291753b7ae508a548ac309c1a4ae5be0f7b76b6c4b67be9f079475bd';

async function loadActivities() {
    try {
        // 1. Cargar todas las actividades
        const res = await fetch(`${API_BASE}/activities`, {
            headers: { 'x-api-key': API_KEY }
        });
        if (res.ok) {
            const data = await res.json();
            allActivities = Array.isArray(data) ? data : (data.items || []);
        }

        // 2. Cargar actividades unidas del usuario (si está logueado)
        let joined = [];
        if (isLoggedIn()) {
            try {
                const userRes = await authFetch(`${API_BASE}/users/me`);
                if (userRes && userRes.ok) {
                    const userData = await userRes.json();
                    joined = userData.joinedActivities || [];
                }
            } catch (e) {
                console.error('Error loading user data:', e);
            }
        }

        renderCalendar(currentMonth, currentYear, joined);
    } catch (e) {
        console.error('Error loading activities for calendar:', e);
    }
}

function renderCalendar(month, year, joinedActivities = []) {
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevMonthDays = new Date(year, month, 0).getDate();

    const monthDisplay = document.getElementById('month-display');
    const calendarGrid = document.getElementById('calendar-grid');

    if (monthDisplay) {
        monthDisplay.textContent = `${monthNames[month]} ${year}`;
    }

    if (calendarGrid) {
        calendarGrid.innerHTML = '';

        // Cabeceras de días
        const daysOfWeek = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
        daysOfWeek.forEach(day => {
            const header = document.createElement('div');
            header.className = 'day-header';
            header.textContent = day;
            calendarGrid.appendChild(header);
        });

        // Días del mes anterior (relleno)
        for (let i = 0; i < firstDay; i++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'day-cell muted';
            dayCell.style.backgroundColor = '#eee';
            dayCell.textContent = prevMonthDays - firstDay + 1 + i;
            calendarGrid.appendChild(dayCell);
        }

        // Días del mes actual
        // Usamos la lista pasada por parámetro o la de localStorage como fallback (aunque ya no debería usarse localStorage)
        const joined = joinedActivities.length > 0 ? joinedActivities : [];

        for (let i = 1; i <= daysInMonth; i++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'day-cell';

            // Contenedor del número
            const dayNum = document.createElement('div');
            dayNum.textContent = i;
            dayCell.appendChild(dayNum);

            // Buscar actividades para este día (solo las inscritas)
            const activitiesToday = allActivities.filter(a => {
                if (!a.fecha) return false;
                if (!joined.includes(a._id)) return false;
                const d = new Date(a.fecha);
                return d.getDate() === i && d.getMonth() === month && d.getFullYear() === year;
            });

            activitiesToday.forEach(act => {
                const badge = document.createElement('span');
                badge.className = 'activity-badge';
                badge.textContent = act.nombre;
                badge.style.display = 'block';
                badge.style.fontSize = '0.7rem';
                badge.style.marginTop = '2px';
                badge.style.padding = '2px 4px';
                badge.style.borderRadius = '4px';
                badge.style.backgroundColor = 'var(--color-primary)';
                badge.style.color = 'white';
                badge.style.border = '2px solid #FFD700';
                badge.style.fontWeight = 'bold';

                dayCell.appendChild(badge);
                dayCell.classList.add('activity-day');
                dayCell.style.backgroundColor = 'rgba(255, 215, 0, 0.1)';
            });

            // Resaltar hoy
            const today = new Date();
            if (i === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
                dayCell.style.border = '2px solid var(--color-primary)';
                dayCell.style.fontWeight = 'bold';
            }

            calendarGrid.appendChild(dayCell);
        }
    }
}

function prevMonth() {
    currentMonth--;
    if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
    }
    renderCalendar(currentMonth, currentYear);
}

function nextMonth() {
    currentMonth++;
    if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
    }
    renderCalendar(currentMonth, currentYear);
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('prev-month')?.addEventListener('click', prevMonth);
    document.getElementById('next-month')?.addEventListener('click', nextMonth);

    renderCalendar(currentMonth, currentYear);
    loadActivities();
});

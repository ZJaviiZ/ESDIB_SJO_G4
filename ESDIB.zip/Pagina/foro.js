const API_BASE = '/api';

async function loadPosts() {
    const container = document.getElementById('forum-posts');
    container.innerHTML = '<p>Cargando foro...</p>';

    try {
        const res = await fetch(`${API_BASE}/posts`, {
            headers: { 'x-api-key': '23add26e291753b7ae508a548ac309c1a4ae5be0f7b76b6c4b67be9f079475bd' }
        });
        const posts = await res.json();

        container.innerHTML = '';
        if (posts.length === 0) {
            container.innerHTML = '<p>Aún no hay mensajes. ¡Sé el primero!</p>';
            return;
        }

        const currentUser = getCurrentUser();

        posts.forEach(post => {
            const div = document.createElement('div');
            div.className = 'forum-post';
            div.style.backgroundColor = 'rgba(255,255,255,0.8)';
            div.style.padding = '15px';
            div.style.marginBottom = '15px';
            div.style.borderRadius = '8px';
            div.style.border = '1px solid #ddd';

            const date = new Date(post.createdAt).toLocaleString();

            // Botón de eliminar post (solo para el autor)
            let deletePostBtn = '';
            if (currentUser && post.author.username === currentUser.username) {
                deletePostBtn = `<button class="delete-post-btn" data-post-id="${post._id}" style="background: #e74c3c; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 0.75rem; margin-left: 10px;">🗑️ Eliminar</button>`;
            }

            let repliesHtml = '';
            if (post.replies && post.replies.length > 0) {
                repliesHtml = '<div style="margin-top: 10px; padding-left: 20px; border-left: 2px solid #eee;">';
                post.replies.forEach(r => {
                    const rDate = new Date(r.createdAt).toLocaleString();

                    // Botón de eliminar respuesta (solo para el autor)
                    let deleteReplyBtn = '';
                    if (currentUser && r.author.username === currentUser.username) {
                        deleteReplyBtn = `<button class="delete-reply-btn" data-post-id="${post._id}" data-reply-id="${r._id}" style="background: #e74c3c; color: white; border: none; padding: 2px 6px; border-radius: 3px; cursor: pointer; font-size: 0.7rem; margin-left: 8px;">🗑️</button>`;
                    }

                    repliesHtml += `
                        <div style="margin-bottom: 8px; font-size: 0.9rem;">
                            <strong>${r.author.username}</strong> <span style="color:#666; font-size:0.8rem;">${rDate}</span>${deleteReplyBtn}
                            <p style="margin: 2px 0;">${r.content}</p>
                        </div>
                    `;
                });
                repliesHtml += '</div>';
            }

            // Reply form (only if logged in)
            let replyFormHtml = '';
            if (isLoggedIn()) {
                replyFormHtml = `
                    <form class="reply-form" data-post-id="${post._id}" style="margin-top: 10px; display: flex; gap: 5px;">
                        <input type="text" name="content" placeholder="Responder..." required style="flex:1; padding: 5px; border-radius: 4px; border: 1px solid #ccc;">
                        <button type="submit" class="btn-primary" style="padding: 5px 10px; font-size: 0.8rem;">Enviar</button>
                    </form>
                `;
            }

            div.innerHTML = `
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px; align-items: center;">
                    <div>
                        <span style="font-weight: bold; color: var(--color-primary);">${post.author.username}</span>
                        <span style="font-size: 0.8rem; color: #666; margin-left: 10px;">${date}</span>
                        ${deletePostBtn}
                    </div>
                </div>
                <p style="font-size: 1.1rem; margin-bottom: 10px;">${post.content}</p>
                ${repliesHtml}
                ${replyFormHtml}
            `;
            container.appendChild(div);
        });

    } catch (e) {
        console.error(e);
        container.innerHTML = '<p style="color:red">Error cargando el foro.</p>';
    }
}

async function createPost(e) {
    e.preventDefault();
    if (!isLoggedIn()) return alert('Debes iniciar sesión');

    const content = document.getElementById('new-post-content').value;

    try {
        const res = await authFetch(`${API_BASE}/posts`, {
            method: 'POST',
            body: JSON.stringify({ content })
        });

        if (res.ok) {
            document.getElementById('new-post-content').value = '';
            loadPosts();
        } else {
            alert('Error al publicar');
        }
    } catch (e) {
        console.error(e);
    }
}

async function deletePost(postId) {
    if (!confirm('¿Seguro que quieres eliminar este post?')) return;

    try {
        const res = await authFetch(`${API_BASE}/posts/${postId}`, {
            method: 'DELETE'
        });

        if (res.ok) {
            loadPosts();
        } else {
            const err = await res.json();
            alert('Error al eliminar: ' + (err.error || 'Desconocido'));
        }
    } catch (err) {
        console.error('Delete error:', err);
        alert('Error de conexión');
    }
}

async function deleteReply(postId, replyId) {
    if (!confirm('¿Seguro que quieres eliminar esta respuesta?')) return;

    try {
        const res = await authFetch(`${API_BASE}/posts/${postId}/replies/${replyId}`, {
            method: 'DELETE'
        });

        if (res.ok) {
            loadPosts();
        } else {
            const err = await res.json();
            alert('Error al eliminar: ' + (err.error || 'Desconocido'));
        }
    } catch (err) {
        console.error('Delete error:', err);
        alert('Error de conexión');
    }
}

// Event Delegation for Replies
document.addEventListener('submit', async (e) => {
    if (e.target.matches('.reply-form')) {
        e.preventDefault();
        const form = e.target;
        const postId = form.dataset.postId;
        const input = form.elements.content;
        const content = input.value;

        console.log('Submitting reply for post:', postId);

        try {
            const res = await authFetch(`${API_BASE}/posts/${postId}/replies`, {
                method: 'POST',
                body: JSON.stringify({ content })
            });

            console.log('Response status:', res.status);

            if (res.ok) {
                loadPosts();
            } else {
                const err = await res.json();
                alert('Error al responder: ' + (err.error || 'Desconocido'));
            }
        } catch (err) {
            console.error('Reply error:', err);
            alert('Error de conexión');
        }
    }
});

// Event Delegation for Delete Buttons
document.addEventListener('click', async (e) => {
    if (e.target.matches('.delete-post-btn') || e.target.closest('.delete-post-btn')) {
        const btn = e.target.matches('.delete-post-btn') ? e.target : e.target.closest('.delete-post-btn');
        const postId = btn.dataset.postId;
        await deletePost(postId);
    }

    if (e.target.matches('.delete-reply-btn') || e.target.closest('.delete-reply-btn')) {
        const btn = e.target.matches('.delete-reply-btn') ? e.target : e.target.closest('.delete-reply-btn');
        const postId = btn.dataset.postId;
        const replyId = btn.dataset.replyId;
        await deleteReply(postId, replyId);
    }
});

document.addEventListener('DOMContentLoaded', () => {
    loadPosts();

    const form = document.getElementById('new-post-form');
    if (form) {
        if (isLoggedIn()) {
            form.addEventListener('submit', createPost);
        } else {
            form.style.display = 'none'; // Hide if not logged in
            document.getElementById('login-warning').style.display = 'block';
        }
    }
});

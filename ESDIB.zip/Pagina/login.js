const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const toggleBtn = document.getElementById('toggle-btn');
const formTitle = document.getElementById('form-title');
const errorMsg = document.getElementById('error-msg');

let isLogin = true;

toggleBtn.addEventListener('click', () => {
    isLogin = !isLogin;
    if (isLogin) {
        loginForm.style.display = 'flex';
        registerForm.style.display = 'none';
        formTitle.textContent = 'Iniciar Sesión';
        toggleBtn.textContent = '¿No tienes cuenta? Regístrate';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'flex';
        formTitle.textContent = 'Crear Cuenta';
        toggleBtn.textContent = '¿Ya tienes cuenta? Inicia Sesión';
    }
    errorMsg.style.display = 'none';
});

function showError(msg) {
    errorMsg.textContent = msg;
    errorMsg.style.display = 'block';
}

// LOGIN
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': '23add26e291753b7ae508a548ac309c1a4ae5be0f7b76b6c4b67be9f079475bd'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Error al entrar');

        saveAuth(data.token, data.username, data._id);
        window.location.href = 'actividades.html'; // Redirigir a actividades
    } catch (err) {
        showError(err.message);
    }
});

// REGISTER
registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;
    const confirm = document.getElementById('reg-confirm').value;

    if (password !== confirm) return showError('Las contraseñas no coinciden');

    try {
        const res = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': '23add26e291753b7ae508a548ac309c1a4ae5be0f7b76b6c4b67be9f079475bd'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Error al registrarse');

        alert('Cuenta creada con éxito. Ahora inicia sesión.');
        // Switch to login
        toggleBtn.click();
    } catch (err) {
        showError(err.message);
    }
});

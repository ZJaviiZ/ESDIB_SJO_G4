const API_BASE = '/api';
const API_KEY = '23add26e291753b7ae508a548ac309c1a4ae5be0f7b76b6c4b67be9f079475bd';

const CATEGORY_ICONS = {
    'Creatividad / Artística': '/icons/creativas.png',
    'Bienestar y Desarrollo Personal': '/icons/bienestar.png',
    'Aire Libre y Naturaleza': '/icons/aire_libre.png',
    'Deporte': '/icons/deportes.png',
    'Social y Ocio': '/icons/social.png',
    'Aprendizaje': '/icons/aprendizaje.png',
    'Comunidad': '/icons/comunidad.png',
    'Gastronomía': '/icons/gastronomia.png',
    'Otros': '/icons/otros.png'
};

async function loadActivities() {
    console.log('Iniciando carga de actividades...');
    const container = document.getElementById('activities-container');

    try {
        container.innerHTML = '<p id="loading-msg">Cargando actividades...</p>';

        const res = await fetch(`${API_BASE}/activities`, {
            headers: { 'x-api-key': API_KEY }
        });

        if (!res.ok) {
            const txt = await res.text();
            throw new Error(`Error API: ${res.status} ${txt}`);
        }

        const data = await res.json();
        const activities = Array.isArray(data) ? data : (data.items || []);

        // Cargar actividades unidas del usuario (si está logueado)
        let joined = [];
        if (isLoggedIn()) {
            try {
                const userRes = await authFetch(`${API_BASE}/users/me`);
                if (userRes && userRes.ok) {
                    const userData = await userRes.json();
                    joined = userData.joinedActivities || [];
                }
            } catch (e) {
                console.error('Error loading user data:', e);
            }
        }

        container.innerHTML = '';

        if (activities.length === 0) {
            container.innerHTML = '<p>No hay actividades programadas.</p>';
            return;
        }

        activities.forEach(act => {
            const cat = act.categoria || 'Otros';
            const iconSrc = CATEGORY_ICONS[cat] || CATEGORY_ICONS['Otros'];
            const fecha = act.fecha ? new Date(act.fecha).toLocaleDateString() : 'Fecha por determinar';
            const hora = act.hora || '--:--';
            const lugar = act.lugar || 'Por determinar';
            const inscritos = act.inscritos_max ? `${act.inscritos_max} máx.` : 'Sin límite';

            const isJoined = joined.includes(act._id);

            const card = document.createElement('div');
            card.className = 'card';
            card.style.cssText = 'display: flex; justify-content: space-between; align-items: center; border-left: 4px solid var(--color-primary); border-top: none;';

            const btnText = isJoined ? 'Desinscribirse' : 'Unirme';
            const btnStyle = isJoined ? 'background-color: #d9534f; color: white;' : '';

            card.innerHTML = `
                <div style="display: flex; align-items: center; width: 100%;">
                    <img src="${iconSrc}" alt="${cat}" style="width: 50px; height: 50px; object-fit: contain; margin-right: 15px; border-radius: 50%; background: #f0f0f0; padding: 5px;">
                    <div>
                        <h3 style="font-size: 1.1rem; color: var(--color-primary); font-weight: bold;">${act.nombre}</h3>
                        <p class="text-sm" style="color: #444;">${act.descripcion || ''}</p>
                        <p style="font-size: 0.75rem; color: #666; margin-top: 0.5rem;">Fecha: ${fecha}, ${hora} | Lugar: ${lugar} | Inscritos: ${inscritos}</p>
                    </div>
                </div>
                <button class="btn-primary join-btn" data-id="${act._id}" style="font-size: 0.9rem; padding: 0.5rem 1rem; white-space: nowrap; margin-left: 10px; ${btnStyle}">${btnText}</button>
            `;

            // Add event listener to the button
            const btn = card.querySelector('.join-btn');
            if (isJoined) {
                btn.addEventListener('click', function () {
                    unjoinActivity(act._id, this);
                });
            } else {
                btn.addEventListener('click', function () {
                    joinActivity(act._id, this);
                });
            }

            container.appendChild(card);
        });

    } catch (error) {
        console.error('Error en loadActivities:', error);
        container.innerHTML = `<p style="color: red;">Error cargando actividades: ${error.message}</p>`;
    }
}

async function joinActivity(id, btn) {
    if (!isLoggedIn()) {
        alert('Debes iniciar sesión para unirte a una actividad.');
        window.location.href = 'login.html';
        return;
    }

    try {
        const res = await authFetch(`${API_BASE}/activities/${id}/join`, { method: 'POST' });
        if (res.ok) {
            btn.textContent = 'Desinscribirse';
            btn.style.backgroundColor = '#d9534f';
            btn.style.color = 'white';

            // Remove old listener and add new one
            const newBtn = btn.cloneNode(true);
            btn.parentNode.replaceChild(newBtn, btn);
            newBtn.addEventListener('click', function () {
                unjoinActivity(id, this);
            });

            alert('¡Te has inscrito correctamente!');
        } else {
            alert('Error al inscribirse');
        }
    } catch (e) {
        console.error(e);
        alert('Error de conexión');
    }
}

async function unjoinActivity(id, btn) {
    if (!isLoggedIn()) {
        alert('Debes iniciar sesión.');
        return;
    }

    try {
        const res = await authFetch(`${API_BASE}/activities/${id}/join`, { method: 'DELETE' });
        if (res.ok) {
            btn.textContent = 'Unirme';
            btn.style.backgroundColor = '';
            btn.style.color = '';

            // Remove old listener and add new one
            const newBtn = btn.cloneNode(true);
            btn.parentNode.replaceChild(newBtn, btn);
            newBtn.addEventListener('click', function () {
                joinActivity(id, this);
            });

            alert('Te has desinscrito.');
        } else {
            alert('Error al desinscribirse');
        }
    } catch (e) {
        console.error(e);
        alert('Error de conexión');
    }
}

document.addEventListener('DOMContentLoaded', loadActivities);

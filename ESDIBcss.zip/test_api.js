const API_KEY = '23add26e291753b7ae508a548ac309c1a4ae5be0f7b76b6c4b67be9f079475bd';
const URL = 'http://localhost:4000/api/activities';

async function test() {
    try {
        const res = await fetch(URL, {
            headers: { 'x-api-key': API_KEY }
        });
        console.log('Status:', res.status);
        if (!res.ok) {
            const txt = await res.text();
            console.log('Error body:', txt);
            return;
        }
        const data = await res.json();
        console.log('Data received:', JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('Fetch error:', e);
    }
}

test();

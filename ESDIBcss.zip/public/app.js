//CONFIG
// const API_BASE = 'http://127.0.0.1:4000/api'; //Backend de forma local
// const API_BASE = 'https://esdibdemo.azurewebsites.net/api'; //Backend para azure
const API_BASE = '/api'; // Relative path if served from same origin

const API_KEY = '23add26e291753b7ae508a548ac309c1a4ae5be0f7b76b6c4b67be9f079475bd'; //API KEY del backend

// Estado
let editingId = null; //Para el sistema de edicion

// Iconos por categoría (Rutas de imágenes)
const CATEGORY_ICONS = {
    'Creatividad / Artística': 'icons/creativas.png',
    'Bienestar y Desarrollo Personal': 'icons/bienestar.png',
    'Aire Libre y Naturaleza': 'icons/aire_libre.png',
    'Deporte': 'icons/deportes.png',
    'Social y Ocio': 'icons/social.png',
    'Aprendizaje': 'icons/aprendizaje.png',
    'Comunidad': 'icons/comunidad.png',
    'Gastronomía': 'icons/gastronomia.png',
    'Otros': 'icons/otros.png'
};

//Funciones helpers
const q = (id) => document.getElementById(id);
const val = (id) => (q(id)?.value ?? '').trim();
const toIntOrNull = s => (s && s.trim() !== '' ? parseInt(s, 10) : null);
function toNullIfEmpty(s) { if (s == null) return null; const t = String(s).trim(); return t === '' ? null : t; }
//Funcion para adaptar el _id de mongo a string
function normId(p) {
    if (!p || !p._id) return null;
    if (typeof p._id === 'string') return p._id;
    if (typeof p._id === 'object' && p._id.$oid) return p._id.$oid;
    try { return String(p._id); } catch { return null; }
}

//Función para errores y cabeceras
async function apiFetch(path, options = {}) {
    // Use API_BASE if path is relative
    const url = path.startsWith('http') ? path : `${API_BASE}${path.replace('/api', '')}`;

    const res = await fetch(url, {
        ...options,
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY, ...(options.headers || {}) }
    });
    if (!res.ok) {
        const msg = await res.text().catch(() => 'Error');
        throw new Error(msg || 'Error de red');
    }
    return res.status !== 204 ? res.json() : null;
}

//Función para obtener todo el contenido de la BBDD y crear un listado
async function cargarLista() {
    try {
        const data = await apiFetch('/api/activities', { method: 'GET' });
        const activities = Array.isArray(data) ? data : (Array.isArray(data?.items) ? data.items : []);
        const list = q('activities-list');
        if (!list) return;
        list.innerHTML = '';

        for (const a of activities) {
            const li = document.createElement('li');
            li.className = 'activity-item';

            // Icono (Imagen)
            const cat = a.categoria || 'Otros';
            const iconSrc = CATEGORY_ICONS[cat] || CATEGORY_ICONS['Otros'];

            const iconImg = document.createElement('img');
            iconImg.className = 'activity-icon-img';
            iconImg.src = iconSrc;
            iconImg.alt = cat;
            // Fix infinite loop: remove onerror after first trigger
            iconImg.onerror = function () {
                this.onerror = null;
                this.src = CATEGORY_ICONS['Otros'];
            };

            const header = document.createElement('div');
            header.className = 'activity-header';
            header.textContent = a?.nombre || '(sin nombre)';

            const details = document.createElement('div');
            details.className = 'activity-details';
            const fechaStr = a.fecha ? new Date(a.fecha).toLocaleDateString() : 'Sin fecha';
            details.innerHTML = `
            <div><strong>Categoría:</strong> ${cat}</div>
            <div><strong>Fecha:</strong> ${fechaStr} | <strong>Hora:</strong> ${a.hora || '--:--'}</div>
            <div><strong>Lugar:</strong> ${a.lugar || 'N/A'} | <strong>Máx:</strong> ${a.inscritos_max || '∞'}</div>
            <div>${a.descripcion || ''}</div>
          `;

            // Acciones
            const actions = document.createElement('div');
            actions.className = 'activity-actions';
            const edit = document.createElement('button');
            edit.textContent = 'Editar';
            edit.onclick = () => startEdit(a);

            const del = document.createElement('button');
            del.textContent = 'Eliminar';
            del.onclick = async () => {
                const id = normId(a);
                if (!id) return alert('ID no válido');
                if (!confirm('¿Eliminar este registro?')) return;
                try {
                    await apiFetch(`/api/activities/${id}`, { method: 'DELETE' });
                    await cargarLista();
                    if (editingId === id) resetForm();
                } catch (e) {
                    alert('Error al eliminar: ' + e.message);
                }
            };

            actions.appendChild(edit);
            actions.appendChild(del);

            li.appendChild(iconImg); // Add icon image
            li.appendChild(header);
            li.appendChild(details);
            li.appendChild(actions);
            list.appendChild(li);
        }
    } catch (e) {
        console.error(e);
        alert('Error al cargar la lista: ' + e.message);
    }
}

// Construir el payload JSON para UPDATE
function buildJsonPayloadFromForm() {
    return {
        nombre: val('nombre'),
        descripcion: val('descripcion'),
        fecha: val('fecha') || null,
        hora: val('hora') || null,
        lugar: val('lugar') || null,
        inscritos_max: toIntOrNull(val('inscritos_max')),
        categoria: val('categoria') || 'Otros'
    };
}


//Función que envia los datos del formulario al backend
async function onSubmitForm(ev) {
    ev.preventDefault();
    const btn = q('upload-button');
    btn.disabled = true;

    try {
        if (!val('nombre')) {
            alert('El campo "Nombre" es obligatorio');
            return;
        }

        const payload = buildJsonPayloadFromForm();
        const method = editingId ? 'PUT' : 'POST';
        const url = editingId ? `/api/activities/${editingId}` : `/api/activities`;

        await apiFetch(url, {
            method: method,
            body: JSON.stringify(payload)
        });

        alert(editingId ? 'Registro actualizado' : 'Registro creado');
        await cargarLista();
        resetForm();

    } catch (e) {
        console.error(e);
        alert('Error al guardar: ' + e.message);
    } finally {
        btn.disabled = false;
    }
}


//Función para resetear el formulario
function resetForm() {
    q('alta_activity')?.reset();
    editingId = null;
    const label = document.querySelector('#upload-button label');
    if (label) label.textContent = 'GUARDAR';
    q('cancel-edit').style.display = 'none';
    const title = document.querySelector('.title');
    if (title) title.textContent = 'NUEVA ACTIVIDAD';
}

// Esto es para rellenar todo el formulario con los datos del registro a editar
function startEdit(p) {
    const id = normId(p);
    if (!id) return alert('ID no válido');
    editingId = id;

    q('nombre').value = p.nombre || '';
    q('descripcion').value = p.descripcion || '';
    q('hora').value = p.hora || '';
    q('lugar').value = p.lugar || '';
    q('inscritos_max').value = (p.inscritos_max ?? '') + '';
    q('categoria').value = p.categoria || 'Otros';

    if (p.fecha) {
        const d = new Date(p.fecha);
        q('fecha').value = isNaN(d.getTime()) ? '' :
            `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    } else {
        q('fecha').value = '';
    }

    const label = document.querySelector('#upload-button label');
    if (label) label.textContent = 'ACTUALIZAR';
    q('cancel-edit').style.display = 'inline-block';
    const title = document.querySelector('.title');
    if (title) title.textContent = 'EDITAR ACTIVIDAD';

    q('nombre').focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

//Arranqueee!!!
document.addEventListener('DOMContentLoaded', () => {
    cargarLista();
    q('alta_activity')?.addEventListener('submit', onSubmitForm);
    q('cancel-edit')?.addEventListener('click', resetForm);
});
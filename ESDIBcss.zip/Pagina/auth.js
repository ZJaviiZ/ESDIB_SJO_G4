const AUTH_TOKEN_KEY = 'auth_token';
const AUTH_USER_KEY = 'auth_user';

const API_BASE_AUTH = '/api/auth';

// Guardar sesión
function saveAuth(token, username, id) {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify({ username, _id: id }));
}

// Borrar sesión
function clearAuth() {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(AUTH_USER_KEY);
}

// Obtener token
function getAuthToken() {
    return localStorage.getItem(AUTH_TOKEN_KEY);
}

// Obtener usuario
function getCurrentUser() {
    const u = localStorage.getItem(AUTH_USER_KEY);
    return u ? JSON.parse(u) : null;
}

// ¿Está logueado?
function isLoggedIn() {
    return !!getAuthToken();
}

// Cerrar sesión
function logout() {
    clearAuth();
    window.location.href = 'login.html';
}

// Helper para fetch con auth
async function authFetch(url, options = {}) {
    const token = getAuthToken();
    const headers = {
        'Content-Type': 'application/json',
        ...(options.headers || {})
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    // API Key siempre necesaria si el backend la pide (aunque auth por token suele reemplazarla o complementarla)
    // En server.js: app.use('/api', apiKeyGuard) -> requiere x-api-key SIEMPRE.
    // Así que la añadimos.
    headers['x-api-key'] = '23add26e291753b7ae508a548ac309c1a4ae5be0f7b76b6c4b67be9f079475bd';

    const res = await fetch(url, { ...options, headers });

    if (res.status === 401) {
        // Token expirado o inválido
        logout();
        throw new Error('Sesión expirada');
    }

    return res;
}

// UI Helpers
function updateAuthUI() {
    const authArea = document.querySelector('.auth-area');
    if (!authArea) return;

    const user = getCurrentUser();
    if (user) {
        authArea.innerHTML = `
            <span style="margin-right: 10px; font-weight: bold; color: white;">Hola, ${user.username}</span>
            <a href="#" id="logout-btn" style="color: white; font-weight: 600; text-decoration: underline;">(Salir)</a>
        `;
        document.getElementById('logout-btn').addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    } else {
        // Check if we are in Pagina folder or root to adjust link
        const isPagina = window.location.pathname.includes('/pagina/');
        const loginLink = isPagina ? 'login.html' : 'pagina/login.html';

        authArea.innerHTML = `
            <a href="${loginLink}">Iniciar Sesión / Crear Cuenta</a>
        `;
    }
}

// Init
document.addEventListener('DOMContentLoaded', () => {
    console.log('Auth.js loaded. Checking auth state...');
    updateAuthUI();
});
